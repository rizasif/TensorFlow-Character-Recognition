# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.11.0.dev0'
__hash__ = 'f5630be17654166c4d861620035b1b4fc876cc27'
__date__ = '20180710'
